

<?php $__env->startSection('title', 'Manajemen Kategori'); ?>
<?php $__env->startSection('page-title', 'Manajemen Kategori'); ?>

<?php $__env->startSection('page-actions'); ?>
<a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-brown">
    <i class="bi bi-plus-circle"></i> Tambah Kategori
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card border-0 shadow-sm">
    <div class="card-header card-header-custom">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="mb-0">
                <i class="bi bi-tags me-2"></i>Daftar Kategori
            </h5>
            <span class="badge bg-light text-dark"><?php echo e($categories->total()); ?> kategori</span>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover table-custom mb-0">
                <thead>
                    <tr>
                        <th width="60" class="text-center">#</th>
                        <th>Nama Kategori</th>
                        <th class="text-center">Jumlah Produk</th>
                        <th class="text-center">Dibuat</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-center align-middle">
                            <span class="badge badge-brown"><?php echo e($loop->iteration + (($categories->currentPage() - 1) * $categories->perPage())); ?></span>
                        </td>
                        <td class="align-middle">
                            <h6 class="mb-0 fw-bold"><?php echo e($category->nama_kategori); ?></h6>
                        </td>
                        <td class="text-center align-middle">
                            <span class="badge" style="background: linear-gradient(135deg, rgba(139, 69, 19, 0.1) 0%, rgba(139, 69, 19, 0.2) 100%); color: #8b4513; border: 1px solid #8b4513;">
                                <?php echo e($category->produk_count); ?> produk
                            </span>
                        </td>
                        <td class="text-center align-middle">
                            <small class="text-muted"><?php echo e($category->created_at->format('d/m/Y')); ?></small>
                        </td>
                        <td class="text-center align-middle">
                            <div class="btn-group btn-group-sm" role="group">
                                <a href="<?php echo e(route('admin.categories.edit', $category->id)); ?>" 
                                   class="btn btn-outline-brown"
                                   data-bs-toggle="tooltip"
                                   title="Edit">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form action="<?php echo e(route('admin.categories.destroy', $category->id)); ?>" 
                                      method="POST" 
                                      class="d-inline"
                                      onsubmit="return confirm('Hapus kategori ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" 
                                            class="btn btn-outline-danger"
                                            data-bs-toggle="tooltip"
                                            title="Hapus">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-5">
                            <div class="py-3">
                                <i class="bi bi-tags display-4 text-muted mb-3"></i>
                                <p class="text-muted mb-4">Belum ada kategori</p>
                                <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-brown">
                                    <i class="bi bi-plus-circle me-2"></i>Tambah Kategori
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        <?php if($categories->hasPages()): ?>
        <div class="card-footer border-0 bg-light">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">
                        Menampilkan <?php echo e($categories->firstItem()); ?> - <?php echo e($categories->lastItem()); ?> dari <?php echo e($categories->total()); ?> kategori
                    </small>
                </div>
                <div>
                    <?php echo e($categories->links()); ?>

                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\project-marnijayabatik\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>