

<?php $__env->startSection('title', $product->nama_produk . ' - Batik Marni Jaya'); ?>

<?php $__env->startSection('sidebar-gallery'); ?>
<div class="sidebar-gallery w-full p-tb-30">
    <span class="mtext-101 cl5">
        Galeri Produk
    </span>

    <div class="flex-w flex-sb p-t-36 gallery-lb">
        <?php
            // Ambil gambar produk untuk gallery sidebar
            $galleryImages = [];
            foreach($products as $product) {
                if($product->gambar) {
                    $galleryImages[] = $product->gambar;
                }
                if($product->gambar_detail) {
                    $galleryImages[] = $product->gambar_detail;
                }
                if($product->gambar_detail2) {
                    $galleryImages[] = $product->gambar_detail2;
                }
            }
            $galleryImages = array_slice(array_unique($galleryImages), 0, 9);
        ?>
        
        <?php $__currentLoopData = $galleryImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                // Cek path gambar
                $imagePath = 'images/products/' . $image;
                if (!file_exists(public_path($imagePath))) {
                    $imagePath = 'images/products/detail/' . $image;
                }
                if (!file_exists(public_path($imagePath))) {
                    $imagePath = 'images/products/detail2/' . $image;
                }
            ?>
            
            <?php if(file_exists(public_path($imagePath))): ?>
            <!-- item gallery sidebar -->
            <div class="wrap-item-gallery m-b-10">
                <a class="item-gallery bg-img1" href="<?php echo e(asset($imagePath)); ?>" data-lightbox="gallery" 
                style="background-image: url('<?php echo e(asset($imagePath)); ?>');"></a>
            </div>
            <?php else: ?>
            <!-- item gallery sidebar default -->
            <div class="wrap-item-gallery m-b-10">
                <a class="item-gallery bg-img1" href="<?php echo e(asset('images/gallery-0' . (($index % 9) + 1) . '.jpg')); ?>" data-lightbox="gallery" 
                style="background-image: url('<?php echo e(asset('images/gallery-0' . (($index % 9) + 1) . '.jpg')); ?>');"></a>
            </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar-about'); ?>
<div class="sidebar-gallery w-full">
    <span class="mtext-101 cl5">
        Tentang Batik Marni Jaya
    </span>

    <p class="stext-108 cl6 p-t-27">
        Batik adalah kain Budaya Jawa Indonesia bergambar yang pembuatannya secara khusus dengan menuliskan atau menerakan malam pada kain itu, kemudian pengolahannya diproses dengan cara tertentu yang memiliki kekhasan. sebagai keseluruhan teknik, teknologi, serta pengembangan motif dan budaya yang terkait, oleh UNESCO telah ditetapkan sebagai Warisan Kemanusiaan untuk Budaya Lisan dan Nonbendawi sejak 2 Oktober 2009. Sejak saat itu, 2 Oktober ditetapkan sebagai Hari Batik Nasional.
    </p>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- breadcrumb -->
<div class="container">
    <div class="bread-crumb flex-w p-l-25 p-r-15 p-t-100 p-lr-0-lg">
        <a href="<?php echo e(route('home')); ?>" class="stext-109 cl8 hov-cl1 trans-04">
            Home
            <i class="fa fa-angle-right m-l-9 m-r-10" aria-hidden="true"></i>
        </a>

        <a href="<?php echo e(route('products.index')); ?>" class="stext-109 cl8 hov-cl1 trans-04">
            Produk
            <i class="fa fa-angle-right m-l-9 m-r-10" aria-hidden="true"></i>
        </a>

        
        <?php
            // Cek apakah relasi kategori dimuat dan tersedia
            $kategori = $product->kategori; // Ini adalah relasi object (jika dengan() atau load())
        ?>
        
        <?php if($kategori && is_object($kategori) && property_exists($kategori, 'id')): ?>
            <a href="<?php echo e(route('products.index', ['kategori' => $kategori->id])); ?>" class="stext-109 cl8 hov-cl1 trans-04">
                <?php echo e($kategori->nama_kategori); ?>

                <i class="fa fa-angle-right m-l-9 m-r-10" aria-hidden="true"></i>
            </a>
        <?php elseif($product->kategori && is_numeric($product->kategori)): ?>
            
            <?php
                // Coba ambil kategori dari database
                $kategoriModel = \App\Models\Category::find($product->kategori);
            ?>
            <?php if($kategoriModel): ?>
                <a href="<?php echo e(route('products.index', ['kategori' => $kategoriModel->id])); ?>" class="stext-109 cl8 hov-cl1 trans-04">
                    <?php echo e($kategoriModel->nama_kategori); ?>

                    <i class="fa fa-angle-right m-l-9 m-r-10" aria-hidden="true"></i>
                </a>
            <?php endif; ?>
        <?php endif; ?>

        <span class="stext-109 cl4">
            <?php echo e($product->nama_produk); ?>

        </span>
    </div>
</div>
    
<!-- Product Detail -->
<section class="sec-product-detail bg0 p-t-65 p-b-60">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-lg-7 p-b-30">
                <div class="p-l-25 p-r-30 p-lr-0-lg">
                    <div class="wrap-slick3 flex-sb flex-w">
                        <div class="wrap-slick3-dots"></div>
                        <div class="wrap-slick3-arrows flex-sb-m flex-w"></div>

                        <div class="slick3 gallery-lb">
                            <?php
                                // Siapkan array semua gambar
                                $allImages = [];
                                
                                // Gambar utama
                                $gambarUtama = $product->gambar ?: 'default.jpeg';
                                $allImages[] = [
                                    'type' => 'main',
                                    'path' => 'images/products/' . $gambarUtama,
                                    'thumb' => 'images/products/' . $gambarUtama
                                ];
                                
                                // Gambar detail
                                if (!empty($gambarDetailArray)) {
                                    foreach ($gambarDetailArray as $gambar) {
                                        $allImages[] = [
                                            'type' => 'detail',
                                            'path' => 'images/products/detail/' . $gambar,
                                            'thumb' => 'images/products/detail/' . $gambar
                                        ];
                                    }
                                }
                                
                                // Gambar detail2
                                if (!empty($gambarDetail2Array)) {
                                    foreach ($gambarDetail2Array as $gambar) {
                                        $allImages[] = [
                                            'type' => 'detail2',
                                            'path' => 'images/products/detail2/' . $gambar,
                                            'thumb' => 'images/products/detail2/' . $gambar
                                        ];
                                    }
                                }
                            ?>
                            
                            <?php $__currentLoopData = $allImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item-slick3" data-thumb="<?php echo e(asset($image['thumb'])); ?>">
                                <div class="wrap-pic-w pos-relative">
                                    <img src="<?php echo e(asset($image['path'])); ?>" alt="<?php echo e($product->nama_produk); ?>">

                                    <a class="flex-c-m size-108 how-pos1 bor0 fs-16 cl10 bg0 hov-btn3 trans-04" 
                                       href="<?php echo e(asset($image['path'])); ?>">
                                        <i class="fa fa-expand"></i>
                                    </a>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
                
            <div class="col-md-6 col-lg-5 p-b-30">
                <div class="p-r-50 p-t-5 p-lr-0-lg">
                    <h4 class="mtext-105 cl2 js-name-detail p-b-14">
                        <?php echo e($product->nama_produk); ?>

                    </h4>

                    <span class="mtext-106 cl2">
                        Rp <?php echo e(number_format($product->harga, 0, ',', '.')); ?>

                    </span>

                    <!-- Informasi tambahan -->
                    <div class="stext-102 cl3 p-t-10">
                        <?php if($product->kategori && is_object($product->kategori)): ?>
                            <span class="cl6 size-206"><?php echo e($product->kategori->nama_kategori); ?></span>
                        <?php else: ?>
                            <span class="cl6 size-206">
                                <?php echo e(\App\Models\Category::find($product->kategori)->nama_kategori ?? 'Tidak ada kategori'); ?>

                            </span>
                        <?php endif; ?>
                        
                        <?php if($product->motif): ?>
                        <div class="flex-w flex-t p-b-5">
                            <span class="cl3 size-205" style="width: 100px;">Motif:</span>
                            <span class="cl6 size-206"><?php echo e($product->motif->nama_motif); ?></span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if($product->berat): ?>
                        <div class="flex-w flex-t p-b-5">
                            <span class="cl3 size-205" style="width: 100px;">Berat:</span>
                            <span class="cl6 size-206"><?php echo e($product->berat); ?> gram</span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if($product->jenis_kain): ?>
                        <div class="flex-w flex-t p-b-5">
                            <span class="cl3 size-205" style="width: 100px;">Bahan:</span>
                            <span class="cl6 size-206"><?php echo e($product->jenis_kain); ?></span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if($product->ukuran): ?>
                        <div class="flex-w flex-t p-b-5">
                            <span class="cl3 size-205" style="width: 100px;">Ukuran:</span>
                            <span class="cl6 size-206"><?php echo e($product->ukuran); ?> cm</span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if($product->panjang_tali): ?>
                        <div class="flex-w flex-t p-b-5">
                            <span class="cl3 size-205" style="width: 100px;">Panjang Tali:</span>
                            <span class="cl6 size-206"><?php echo e($product->panjang_tali); ?> cm</span>
                        </div>
                        <?php endif; ?>
                    </div>

                    <p class="stext-102 cl3 p-t-23">
                        <?php echo e($product->deskripsi); ?>

                    </p>
                    
                    <!-- Quantity dan Add to Cart -->
                    <div class="p-t-33">
                        <div class="flex-w flex-r-m p-b-10">
                            <div class="size-204 flex-w flex-m respon6-next">
                                <div class="wrap-num-product flex-w m-r-20 m-tb-10">
                                    <div class="btn-num-product-down cl8 hov-btn3 trans-04 flex-c-m">
                                        <i class="fs-16 zmdi zmdi-minus"></i>
                                    </div>

                                    <input class="mtext-104 cl3 txt-center num-product" type="number" 
                                           name="num-product" value="1" id="quantity-main" min="<?php echo e(max(1, $product->min_beli ?? 1)); ?>">

                                    <div class="btn-num-product-up cl8 hov-btn3 trans-04 flex-c-m">
                                        <i class="fs-16 zmdi zmdi-plus"></i>
                                    </div>
                                </div>

                                <button class="flex-c-m stext-101 cl0 size-101 bg1 bor1 hov-btn1 p-lr-15 trans-04 js-whatsapp-main"
                                        data-product-id="<?php echo e($product->id_produk); ?>"
                                        data-product-name="<?php echo e($product->nama_produk); ?>"
                                        data-product-price="<?php echo e($product->harga); ?>"
                                        data-product-category="<?php echo e($product->kategori->nama_kategori ?? ''); ?>"
                                        data-product-motif="<?php echo e($product->motif->nama_motif ?? ''); ?>"
                                        data-product-berat="<?php echo e($product->berat); ?> gram"
                                        data-product-bahan="<?php echo e($product->jenis_kain); ?>"
                                        data-product-ukuran="<?php echo e($product->ukuran); ?> cm"
                                        data-product-panjang="<?php echo e($product->panjang_tali); ?> cm"
                                        data-product-desc="<?php echo e($product->deskripsi); ?>">
                                    Pesan Via WhatsApp
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="bor10 m-t-50 p-t-43 p-b-40">
            <!-- Tab01 -->
            <div class="tab01">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item p-b-10">
                        <a class="nav-link active" data-toggle="tab" href="#description" role="tab">Deskripsi</a>
                    </li>

                    <li class="nav-item p-b-10">
                        <a class="nav-link" data-toggle="tab" href="#information" role="tab">Informasi Tambahan</a>
                    </li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content p-t-43">
                    <!-- Description -->
                    <div class="tab-pane fade show active" id="description" role="tabpanel">
                        <div class="how-pos2 p-lr-15-md">
                            <p class="stext-102 cl6">
                                <?php echo e($product->deskripsi); ?>

                            </p>
                        </div>
                    </div>

                    <!-- Additional Information -->
                    <div class="tab-pane fade" id="information" role="tabpanel">
                        <div class="row">
                            <div class="col-sm-10 col-md-8 col-lg-6 m-lr-auto">
                                <ul class="p-lr-28 p-lr-15-sm">
                                    <?php if($product->berat): ?>
                                    <li class="flex-w flex-t p-b-7">
                                        <span class="stext-102 cl3 size-205">
                                            Berat
                                        </span>
                                        <span class="stext-102 cl6 size-206">
                                            <?php echo e($product->berat); ?> gram
                                        </span>
                                    </li>
                                    <?php endif; ?>

                                    <?php if($product->ukuran): ?>
                                    <li class="flex-w flex-t p-b-7">
                                        <span class="stext-102 cl3 size-205">
                                            Ukuran
                                        </span>
                                        <span class="stext-102 cl6 size-206">
                                            <?php echo e($product->ukuran); ?> cm
                                        </span>
                                    </li>
                                    <?php endif; ?>

                                    <?php if($product->jenis_kain): ?>
                                    <li class="flex-w flex-t p-b-7">
                                        <span class="stext-102 cl3 size-205">
                                            Bahan
                                        </span>
                                        <span class="stext-102 cl6 size-206">
                                            <?php echo e($product->jenis_kain); ?>

                                        </span>
                                    </li>
                                    <?php endif; ?>

                                    <?php if($product->motif): ?>
                                    <li class="flex-w flex-t p-b-7">
                                        <span class="stext-102 cl3 size-205">
                                            Motif
                                        </span>
                                        <span class="stext-102 cl6 size-206">
                                            <?php echo e($product->motif->nama_motif); ?>

                                        </span>
                                    </li>
                                    <?php endif; ?>

                                    <?php if($product->proses_batik): ?>
                                    <li class="flex-w flex-t p-b-7">
                                        <span class="stext-102 cl3 size-205">
                                            Proses Batik
                                        </span>
                                        <span class="stext-102 cl6 size-206">
                                            <?php echo e($product->proses_batik); ?>

                                        </span>
                                    </li>
                                    <?php endif; ?>
                                    
                                    <?php if($product->etalase): ?>
                                    <li class="flex-w flex-t p-b-7">
                                        <span class="stext-102 cl3 size-205">
                                            Etalase
                                        </span>
                                        <span class="stext-102 cl6 size-206">
                                            <?php echo e($product->etalase); ?>

                                        </span>
                                    </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="bg6 flex-c-m flex-w size-302 m-t-73 p-tb-15">
            <span class="stext-107 cl6 p-lr-25">
                Kategori: <?php echo e($product->kategori->nama_kategori ?? 'Tidak ada kategori'); ?>

            </span>
            
            <?php if($product->stok): ?>
            <span class="stext-107 cl6 p-lr-25">
                Stok: <?php echo e($product->stok); ?> pcs
            </span>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Related Products -->
<section class="sec-relate-product bg0 p-t-45 p-b-105">
    <div class="container">
        <div class="p-b-45">
            <h3 class="ltext-106 cl5 txt-center">
                Produk Terkait
            </h3>
        </div>

        <!-- Slide2 -->
        <div class="wrap-slick2">
            <div class="slick2">
                <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        // Tentukan gambar utama
                        $relatedGambar = $related->gambar ?: 'default.jpeg';
                        $relatedGambarPath = public_path('images/products/' . $relatedGambar);
                        
                        if (!file_exists($relatedGambarPath) || empty($related->gambar)) {
                            $relatedGambar = 'default.jpeg';
                        }
                    ?>
                    
                    <div class="item-slick2 p-l-15 p-r-15 p-t-15 p-b-15">
                        <!-- Block2 -->
                        <div class="block2">
                            <div class="block2-pic hov-img0">
                                <img src="<?php echo e(asset('images/products/' . $relatedGambar)); ?>" 
                                     alt="<?php echo e($related->nama_produk); ?>">

                                <a href="#"
                                    class="block2-btn flex-c-m stext-103 cl2 size-102 bg0 bor2 hov-btn1 p-lr-15 trans-04 js-show-modal1"
                                    data-product-id="<?php echo e($related->id_produk); ?>"
                                    data-product-name="<?php echo e($related->nama_produk); ?>"
                                    data-product-price="<?php echo e($related->harga); ?>"
                                    data-product-desc="<?php echo e($related->deskripsi); ?>"
                                    data-product-category="<?php echo e($related->kategori->nama_kategori ?? ''); ?>"  
                                    data-product-motif="<?php echo e($related->motif->nama_motif ?? ''); ?>"        
                                    data-product-berat="<?php echo e($related->berat); ?> gram"        
                                    data-product-bahan="<?php echo e($related->jenis_kain); ?>"
                                    data-product-ukuran="<?php echo e($related->ukuran); ?> cm"        
                                    data-product-panjang="<?php echo e($related->panjang_tali); ?> cm"
                                    data-product-image="<?php echo e($relatedGambar); ?>"
                                    data-product-detail1="<?php echo e($related->gambar_detail); ?>"
                                    data-product-detail2="<?php echo e($related->gambar_detail2); ?>">
                                    Lihat Detail
                                </a>
                            </div>

                            <div class="block2-txt flex-w flex-t p-t-14">
                                <div class="block2-txt-child1 flex-col-l">
                                    <a href="<?php echo e(route('products.show', $related->id_produk)); ?>" 
                                       class="stext-104 cl4 hov-cl1 trans-04 js-name-b2 p-b-6">
                                        <?php echo e($related->nama_produk); ?>

                                    </a>

                                    <span class="stext-105 cl3">
                                        Rp <?php echo e(number_format($related->harga, 0, ',', '.')); ?>

                                    </span>
                                </div>

                                <div class="block2-txt-child2 flex-r p-t-3">
                                    <button class="btn-addwish-b2 dis-block pos-relative js-addwish-b2 js-whatsapp-direct"
                                        data-product-name="<?php echo e($related->nama_produk); ?>"
                                        data-product-price="<?php echo e($related->harga); ?>">
                                        <img class="icon-heart1 dis-block trans-04" src="<?php echo e(asset('images/icons/icon-heart-01.png')); ?>" alt="ICON">
                                        <img class="icon-heart2 dis-block trans-04 ab-t-l" src="<?php echo e(asset('images/icons/icon-heart-02.png')); ?>" alt="ICON">
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        // Quantity handler
        $('.btn-num-product-down').on('click', function(e){
            e.preventDefault();
            var numProduct = Number($(this).next().val());
            if(numProduct > <?php echo e(max(1, $product->min_beli ?? 1)); ?>) {
                $(this).next().val(numProduct - 1);
            }
        });

        $('.btn-num-product-up').on('click', function(e){
            e.preventDefault();
            var numProduct = Number($(this).prev().val());
            $(this).prev().val(numProduct + 1);
        });

        // WhatsApp handler for detail page
        $('.js-whatsapp-main').on('click', function(e) {
            e.preventDefault();
            
            var productName = $(this).data('product-name');
            var productPrice = $(this).data('product-price');
            var productCategory = $(this).data('product-category');
            var productMotif = $(this).data('product-motif');
            var productBerat = $(this).data('product-berat');
            var productBahan = $(this).data('product-bahan');
            var productUkuran = $(this).data('product-ukuran');
            var productPanjang = $(this).data('product-panjang');
            var productDesc = $(this).data('product-desc');
            var quantity = $('#quantity-main').val();
            
            // Build WhatsApp message
            var message = `Halo, saya tertarik dengan produk:\n\n` +
                         `📦 *${productName}*\n` +
                         `💰 Harga: Rp ${parseInt(productPrice).toLocaleString('id-ID')}\n` +
                         `📋 Kategori: ${productCategory}\n` +
                         `🎨 Motif: ${productMotif}\n` +
                         `⚖️ Berat: ${productBerat}\n` +
                         `🧵 Bahan: ${productBahan}\n` +
                         `📏 Ukuran: ${productUkuran}\n` +
                         `📐 Panjang Tali: ${productPanjang}\n` +
                         `🔢 Jumlah: ${quantity} pcs\n` +
                         `📝 Deskripsi: ${productDesc.substring(0, 100)}...\n\n` +
                         `Apakah produk ini tersedia?`;
            
            var whatsappUrl = `https://api.whatsapp.com/send?phone=6282323259808&text=${encodeURIComponent(message)}`;
            window.open(whatsappUrl, '_blank');
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\project-marnijayabatik\resources\views/front/products/show.blade.php ENDPATH**/ ?>