

<?php $__env->startSection('title', 'Edit Kategori'); ?>
<?php $__env->startSection('page-title', 'Edit Kategori'); ?>

<?php $__env->startSection('page-actions'); ?>
<a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-outline-brown">
    <i class="bi bi-arrow-left"></i> Kembali
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header card-header-custom">
                <h5 class="mb-0"><i class="bi bi-pencil me-2"></i>Edit Kategori</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.categories.update', $category->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="mb-4">
                        <label class="form-label required">Nama Kategori</label>
                        <input type="text" 
                               name="nama_kategori" 
                               class="form-control <?php $__errorArgs = ['nama_kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               value="<?php echo e(old('nama_kategori', $category->nama_kategori)); ?>"
                               placeholder="Contoh: Batik Tulis, Batik Cap, dll"
                               required
                               style="border-color: #8b4513;">
                        <?php $__errorArgs = ['nama_kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <!-- Category Info -->
                    <div class="card border-0 shadow-sm mb-4" style="background: linear-gradient(135deg, rgba(139, 69, 19, 0.05) 0%, rgba(139, 69, 19, 0.1) 100%);">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="bi bi-box me-2" style="color: #8b4513;"></i>
                                        <div>
                                            <small class="text-muted d-block">Jumlah Produk</small>
                                            <h6 class="mb-0 fw-bold"><?php echo e($category->produk_count ?? 0); ?></h6>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="bi bi-calendar me-2" style="color: #8b4513;"></i>
                                        <div>
                                            <small class="text-muted d-block">Dibuat</small>
                                            <h6 class="mb-0 fw-bold"><?php echo e($category->created_at->format('d/m/Y')); ?></h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="d-grid">
                        <button type="submit" class="btn btn-brown btn-lg">
                            <i class="bi bi-check-circle me-2"></i>Update Kategori
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\project-marnijayabatik\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>